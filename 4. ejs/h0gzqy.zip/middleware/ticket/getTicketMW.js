/**
 * Betölt egy adott id-hez tartozó jegytípust
 */
const requireOption = require('../requireOption');

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};